import { Language, t } from './i18n';

export interface ExecutionLog {
  text: string;
  delay: number;
}

export interface ExecutionContext {
  command: string;
  userInput: string;
  language: Language;
}

export function calculateExecutionDuration(ctx: ExecutionContext): number {
  const keywords = extractKeywords(ctx.userInput);
  const hasNames = extractNames(ctx.userInput).length > 0;
  const textLength = ctx.userInput.length;

  // Base duration: 45-90 seconds
  let baseDuration = 45000 + Math.random() * 45000;

  // Add complexity based on keywords
  const keywordComplexity = keywords.length * 3000;

  // Add complexity for named entities
  const nameComplexity = hasNames ? 5000 : 0;

  // Add complexity for longer descriptions
  const lengthComplexity = Math.min(textLength * 50, 10000);

  const totalDuration = baseDuration + keywordComplexity + nameComplexity + lengthComplexity;

  // Cap at 90 seconds max
  return Math.min(totalDuration, 90000);
}

function extractNames(text: string): string[] {
  // Extract names enclosed in double asterisks: **Name**
  const matches = text.match(/\*\*([^*]+)\*\*/g);
  if (!matches) return [];

  const names = matches
    .map(match => match.replace(/\*\*/g, '').trim())
    .filter(name => name.length > 0);

  return [...new Set(names)];
}

function extractKeywords(text: string): string[] {
  const keywords: string[] = [];
  const lowerText = text.toLowerCase();

  const keywordMap: Record<string, string[]> = {
    fear: ['scared', 'afraid', 'fear', 'terrified', 'horror', 'panic', 'phobia', 'spider', 'snake', 'height', 'dark'],
    love: ['love', 'attracted', 'crush', 'romantic', 'feelings', 'heart', 'dating', 'relationship', 'girl', 'boy'],
    social: ['talk', 'speak', 'conversation', 'communicate', 'text', 'message', 'meet', 'approach', 'confident', 'anxious', 'nervous'],
    work: ['work', 'job', 'career', 'productivity', 'focus', 'concentrate', 'task', 'project', 'deadline', 'professional'],
    procrastination: ['procrastinate', 'distracted', 'tiktok', 'youtube', 'social media', 'scroll', 'delay', 'avoid', 'put off'],
    energy: ['tired', 'exhausted', 'fatigue', 'sleep', 'energy', 'drained', 'rest', 'wake', 'awake', 'lazy'],
    habit: ['habit', 'addiction', 'compulsive', 'urge', 'craving', 'impulse', 'repeatedly', 'obsessive'],
    future: ['future', 'goal', 'plan', 'dream', 'aspiration', 'vision', 'direction', 'purpose', 'meaning'],
  };

  for (const [category, words] of Object.entries(keywordMap)) {
    if (words.some(w => lowerText.includes(w))) {
      keywords.push(category);
    }
  }

  return keywords.length > 0 ? keywords : ['general'];
}

function generateAnalysisLogs(ctx: ExecutionContext, totalDuration: number): ExecutionLog[] {
  const tx = t(ctx.language);
  const logs: ExecutionLog[] = [];
  const names = extractNames(ctx.userInput);
  const keywords = extractKeywords(ctx.userInput);
  const usedTexts = new Set<string>();

  const analysisVerbs = [
    tx('analysis.analyzing'),
    tx('analysis.detecting'),
    tx('analysis.evaluating'),
    tx('analysis.identifying'),
    tx('analysis.mapping'),
  ];

  const patternTypes = [
    tx('patterns.hesitation'),
    tx('patterns.anxiety'),
    tx('patterns.confidence'),
    tx('patterns.emotional'),
    tx('patterns.behavioral'),
    tx('patterns.interaction'),
    tx('patterns.communication'),
    tx('patterns.distraction'),
    tx('patterns.focus'),
    tx('patterns.productivity'),
    tx('patterns.impulse'),
    tx('patterns.control'),
    tx('patterns.fatigue'),
    tx('patterns.energy'),
    tx('patterns.endurance'),
    tx('patterns.recovery'),
    tx('patterns.fear'),
    tx('patterns.avoidance'),
    tx('patterns.overthinking'),
    tx('patterns.social'),
    tx('patterns.conversational'),
    tx('patterns.spontaneity'),
    tx('patterns.consistency'),
    tx('patterns.direction'),
    tx('patterns.objectives'),
    tx('patterns.decision'),
  ];

  const commandPatterns: Record<string, string[]> = {
    materialize_futur: ['patterns.direction', 'patterns.consistency', 'patterns.objectives', 'patterns.decision'],
    nullify_fear: ['patterns.fear', 'patterns.avoidance', 'patterns.hesitation', 'patterns.anxiety'],
    procrastination_bypass: ['patterns.distraction', 'patterns.focus', 'patterns.productivity', 'patterns.behavioral'],
    love_potion: ['patterns.social', 'patterns.confidence', 'patterns.communication', 'patterns.conversational'],
    urge_blocker: ['patterns.impulse', 'patterns.control', 'patterns.behavioral', 'patterns.hesitation'],
    energy_unlocker: ['patterns.fatigue', 'patterns.energy', 'patterns.endurance', 'patterns.recovery'],
  };

  const relevantPatterns = commandPatterns[ctx.command.replace('/', '')] || patternTypes;
  const shuffledPatterns = [...relevantPatterns].sort(() => Math.random() - 0.5);

  // 40% of total duration for analysis phase
  const analysisDuration = totalDuration * 0.4;
  const numLogs = 8 + Math.floor(Math.random() * 5);
  const avgDelay = analysisDuration / numLogs;

  let patternIndex = 0;
  let attempts = 0;
  const maxAttempts = numLogs * 3;

  while (logs.length < numLogs && attempts < maxAttempts) {
    attempts++;
    let logText = '';
    const verb = analysisVerbs[patternIndex % analysisVerbs.length];

    if (Math.random() < 0.4 && names.length > 0) {
      const name = names[Math.floor(Math.random() * names.length)];
      const patternMap: Record<string, string[]> = {
        'analysis.analyzing': [
          `${ctx.language === 'en' ? 'analyzing' : 'analyse'} ${ctx.language === 'en' ? 'interaction patterns with' : 'schémas d\'interaction avec'} ${name}...`,
          `${ctx.language === 'en' ? 'evaluating' : 'évaluation'} ${ctx.language === 'en' ? 'emotional response towards' : 'réponse émotionnelle envers'} ${name}...`,
        ],
        'analysis.detecting': [
          `${ctx.language === 'en' ? 'detecting' : 'détection'} ${ctx.language === 'en' ? 'communication dynamics involving' : 'dynamique de communication impliquant'} ${name}...`,
        ],
        'analysis.evaluating': [
          `${ctx.language === 'en' ? 'evaluating' : 'évaluation'} ${ctx.language === 'en' ? 'confidence levels around' : 'niveaux de confiance autour de'} ${name}...`,
        ],
      };
      logText = patternMap[verb]?.[Math.floor(Math.random() * (patternMap[verb]?.length || 1))] || `${verb} ${tx(shuffledPatterns[patternIndex % shuffledPatterns.length])}...`;
    } else if (Math.random() < 0.6) {
      const keyword = keywords[Math.floor(Math.random() * keywords.length)];
      const keywordPatterns: Record<string, string[]> = {
        fear: [
          `${ctx.language === 'en' ? 'analyzing fear-related response patterns' : 'analyse des schémas de réponse liés à la peur'}...`,
          `${ctx.language === 'en' ? 'detecting avoidance behaviors' : 'détection des comportements d\'évitement'}...`,
        ],
        love: [
          `${ctx.language === 'en' ? 'evaluating emotional vulnerability levels' : 'évaluation des niveaux de vulnérabilité émotionnelle'}...`,
          `${ctx.language === 'en' ? 'analyzing romantic interaction patterns' : 'analyse des schémas d\'interaction romantique'}...`,
        ],
        social: [
          `${ctx.language === 'en' ? 'detecting social anxiety indicators' : 'détection des indicateurs d\'anxiété sociale'}...`,
          `${ctx.language === 'en' ? 'evaluating communication comfort levels' : 'évaluation des niveaux de confort en communication'}...`,
        ],
        work: [
          `${ctx.language === 'en' ? 'analyzing professional focus patterns' : 'analyse des schémas de concentration professionnelle'}...`,
          `${ctx.language === 'en' ? 'detecting work-related stress factors' : 'détection des facteurs de stress liés au travail'}...`,
        ],
        procrastination: [
          `${ctx.language === 'en' ? 'analyzing distraction dependency' : 'analyse de la dépendance à la distraction'}...`,
          `${ctx.language === 'en' ? 'detecting recurring interruption patterns' : 'détection des schémas d\'interruption récurrents'}...`,
        ],
        energy: [
          `${ctx.language === 'en' ? 'evaluating fatigue accumulation' : 'évaluation de l\'accumulation de fatigue'}...`,
          `${ctx.language === 'en' ? 'analyzing energy distribution cycles' : 'analyse des cycles de distribution d\'énergie'}...`,
        ],
        habit: [
          `${ctx.language === 'en' ? 'detecting impulse trigger patterns' : 'détection des schémas de déclenchement d\'impulsion'}...`,
          `${ctx.language === 'en' ? 'analyzing compulsive behavior loops' : 'analyse des boucles comportementales compulsives'}...`,
        ],
        future: [
          `${ctx.language === 'en' ? 'mapping long-term objective structures' : 'cartographie des structures d\'objectifs à long terme'}...`,
          `${ctx.language === 'en' ? 'evaluating future planning consistency' : 'évaluation de la cohérence de la planification future'}...`,
        ],
      };
      logText = keywordPatterns[keyword]?.[Math.floor(Math.random() * (keywordPatterns[keyword]?.length || 1))] || `${verb} ${tx(shuffledPatterns[patternIndex % shuffledPatterns.length])}...`;
    } else {
      logText = `${verb} ${tx(shuffledPatterns[patternIndex % shuffledPatterns.length])}...`;
    }

    // Only add if not already used
    if (!usedTexts.has(logText)) {
      usedTexts.add(logText);
      const variance = avgDelay * 0.3;
      const delay = avgDelay + (Math.random() - 0.5) * variance * 2;
      logs.push({
        text: logText,
        delay: Math.max(1500, delay),
      });
      patternIndex++;
    }
  }

  return logs;
}

function generateModificationLogs(ctx: ExecutionContext, totalDuration: number): ExecutionLog[] {
  const tx = t(ctx.language);
  const logs: ExecutionLog[] = [];
  const names = extractNames(ctx.userInput);
  const keywords = extractKeywords(ctx.userInput);
  const usedTexts = new Set<string>();

  const modVerbs = [
    tx('analysis.rebuilding'),
    tx('analysis.reducing'),
    tx('analysis.stabilizing'),
    tx('analysis.optimizing'),
    tx('analysis.recalibrating'),
  ];

  // 40% of total duration for modification phase
  const modDuration = totalDuration * 0.4;
  const numLogs = 6 + Math.floor(Math.random() * 4);
  const avgDelay = modDuration / numLogs;

  let attempts = 0;
  const maxAttempts = numLogs * 3;

  while (logs.length < numLogs && attempts < maxAttempts) {
    attempts++;
    const verb = modVerbs[logs.length % modVerbs.length];
    let logText = '';

    if (Math.random() < 0.35 && names.length > 0) {
      const name = names[Math.floor(Math.random() * names.length)];
      const modPatterns = [
        `${ctx.language === 'en' ? 'rebuilding confidence around' : 'reconstruction de la confiance autour de'} ${name}...`,
        `${ctx.language === 'en' ? 'stabilizing emotional response towards' : 'stabilisation de la réponse émotionnelle envers'} ${name}...`,
        `${ctx.language === 'en' ? 'optimizing interaction flow with' : 'optimisation du flux d\'interaction avec'} ${name}...`,
      ];
      logText = modPatterns[Math.floor(Math.random() * modPatterns.length)];
    } else if (Math.random() < 0.5) {
      const keyword = keywords[Math.floor(Math.random() * keywords.length)];
      const modPatterns: Record<string, string[]> = {
        fear: [
          `${ctx.language === 'en' ? 'reducing automatic panic responses' : 'réduction des réponses de panique automatiques'}...`,
          `${ctx.language === 'en' ? 'stabilizing emotional reaction tolerance' : 'stabilisation de la tolérance aux réactions émotionnelles'}...`,
        ],
        love: [
          `${ctx.language === 'en' ? 'rebuilding conversational comfort' : 'reconstruction du confort conversationnel'}...`,
          `${ctx.language === 'en' ? 'optimizing spontaneous expression flow' : 'optimisation du flux d\'expression spontanée'}...`,
        ],
        social: [
          `${ctx.language === 'en' ? 'stabilizing social confidence' : 'stabilisation de la confiance sociale'}...`,
          `${ctx.language === 'en' ? 'reducing overthinking loops' : 'réduction des boucles de suranalyse'}...`,
        ],
        work: [
          `${ctx.language === 'en' ? 'optimizing task engagement' : 'optimisation de l\'engagement dans les tâches'}...`,
          `${ctx.language === 'en' ? 'rebuilding productivity structure' : 'reconstruction de la structure de productivité'}...`,
        ],
        procrastination: [
          `${ctx.language === 'en' ? 'reducing impulsive application switching' : 'réduction des changements d\'application impulsifs'}...`,
          `${ctx.language === 'en' ? 'stabilizing sustained concentration' : 'stabilisation de la concentration soutenue'}...`,
        ],
        energy: [
          `${ctx.language === 'en' ? 'rebuilding recovery cycles' : 'reconstruction des cycles de récupération'}...`,
          `${ctx.language === 'en' ? 'optimizing energy distribution' : 'optimisation de la distribution d\'énergie'}...`,
        ],
        habit: [
          `${ctx.language === 'en' ? 'stabilizing behavioral restraint' : 'stabilisation de la retenue comportementale'}...`,
          `${ctx.language === 'en' ? 'reducing automatic response patterns' : 'réduction des schémas de réponse automatique'}...`,
        ],
        future: [
          `${ctx.language === 'en' ? 'rebuilding directional stability' : 'reconstruction de la stabilité directionnelle'}...`,
          `${ctx.language === 'en' ? 'optimizing decision continuity' : 'optimisation de la continuité décisionnelle'}...`,
        ],
      };
      const patterns = modPatterns[keyword];
      logText = patterns ? patterns[Math.floor(Math.random() * patterns.length)] : `${verb}...`;
    } else {
      const patterns = [
        `${ctx.language === 'en' ? 'rebuilding consistency patterns' : 'reconstruction des schémas de cohérence'}...`,
        `${ctx.language === 'en' ? 'stabilizing behavioral framework' : 'stabilisation du cadre comportemental'}...`,
        `${ctx.language === 'en' ? 'optimizing response mechanisms' : 'optimisation des mécanismes de réponse'}...`,
        `${ctx.language === 'en' ? 'reducing negative feedback loops' : 'réduction des boucles de rétroaction négatives'}...`,
        `${ctx.language === 'en' ? 'recalibrating emotional thresholds' : 'recalibrage des seuils émotionnels'}...`,
        `${ctx.language === 'en' ? 'validating system stability' : 'validation de la stabilité du système'}...`,
      ];
      logText = patterns[Math.floor(Math.random() * patterns.length)];
    }

    // Only add if not already used
    if (!usedTexts.has(logText)) {
      usedTexts.add(logText);
      const variance = avgDelay * 0.3;
      const delay = avgDelay + (Math.random() - 0.5) * variance * 2;
      logs.push({
        text: logText,
        delay: Math.max(2000, delay),
      });
    }
  }

  return logs;
}

function generateValidationLogs(ctx: ExecutionContext, totalDuration: number): ExecutionLog[] {
  const tx = t(ctx.language);
  const logs: ExecutionLog[] = [];

  const validationPatterns = [
    `${ctx.language === 'en' ? 'validating emotional consistency' : 'validation de la cohérence émotionnelle'}...`,
    `${ctx.language === 'en' ? 'validating behavioral stability' : 'validation de la stabilité comportementale'}...`,
    `${ctx.language === 'en' ? 'validating optimization integrity' : 'validation de l\'intégrité de l\'optimisation'}...`,
    `${ctx.language === 'en' ? 'validating response mechanisms' : 'validation des mécanismes de réponse'}...`,
    `${ctx.language === 'en' ? 'confirming stabilization success' : 'confirmation du succès de la stabilisation'}...`,
    `${ctx.language === 'en' ? 'finalizing runtime patches' : 'finalisation des correctifs d\'exécution'}...`,
  ];

  // 20% of total duration for validation phase
  const validationDuration = totalDuration * 0.2;
  const numLogs = 3 + Math.floor(Math.random() * 2);
  const avgDelay = validationDuration / numLogs;
  const usedTexts = new Set<string>();

  let attempts = 0;
  const maxAttempts = numLogs * 3;

  while (logs.length < numLogs && attempts < maxAttempts) {
    attempts++;
    const logText = validationPatterns[Math.floor(Math.random() * validationPatterns.length)];

    if (!usedTexts.has(logText)) {
      usedTexts.add(logText);
      const variance = avgDelay * 0.2;
      const delay = avgDelay + (Math.random() - 0.5) * variance * 2;
      logs.push({
        text: logText,
        delay: Math.max(2500, delay),
      });
    }
  }

  return logs;
}

export interface ExecutionPipelineResult {
  logs: ExecutionLog[];
  totalDuration: number;
}

export function generateExecutionPipeline(ctx: ExecutionContext): ExecutionPipelineResult {
  const totalDuration = calculateExecutionDuration(ctx);
  const analysisLogs = generateAnalysisLogs(ctx, totalDuration);
  const modificationLogs = generateModificationLogs(ctx, totalDuration);
  const validationLogs = generateValidationLogs(ctx, totalDuration);

  return {
    logs: [...analysisLogs, ...modificationLogs, ...validationLogs],
    totalDuration,
  };
}

// Re-export extractKeywords for use in calculateExecutionDuration
function extractKeywordsPublic(text: string): string[] {
  return extractKeywords(text);
}

export function generateWarning(ctx: ExecutionContext): string | null {
  const tx = t(ctx.language);
  if (Math.random() < 0.15) {
    const warnings = [
      tx('warnings.instability'),
      tx('warnings.sync_delayed'),
      tx('warnings.behavioral_conflict'),
      tx('warnings.reinforcement_inconsistency'),
    ];
    return warnings[Math.floor(Math.random() * warnings.length)];
  }
  return null;
}

export function generateStatusText(ctx: ExecutionContext, progress: number): string {
  const keywords = extractKeywords(ctx.userInput);
  const tx = t(ctx.language);

  const statusTemplates: Record<string, string[]> = {
    fear: [
      ctx.language === 'en' ? 'REDUCING FEAR RESPONSE' : 'RÉDUCTION DE LA RÉPONSE DE PEUR',
      ctx.language === 'en' ? 'STABILIZING EMOTIONAL REACTION' : 'STABILISATION DE LA RÉACTION ÉMOTIONNELLE',
    ],
    love: [
      ctx.language === 'en' ? 'REBUILDING SOCIAL CONFIDENCE' : 'RECONSTRUCTION DE LA CONFIANCE SOCIALE',
      ctx.language === 'en' ? 'OPTIMIZING COMMUNICATION FLOW' : 'OPTIMISATION DU FLUX DE COMMUNICATION',
    ],
    social: [
      ctx.language === 'en' ? 'STABILIZING INTERACTION PATTERNS' : 'STABILISATION DES SCHÉMAS D\'INTERACTION',
      ctx.language === 'en' ? 'REBUILDING CONFIDENCE FRAMEWORK' : 'RECONSTRUCTION DU CADRE DE CONFIANCE',
    ],
    work: [
      ctx.language === 'en' ? 'OPTIMIZING PRODUCTIVITY STRUCTURE' : 'OPTIMISATION DE LA STRUCTURE DE PRODUCTIVITÉ',
      ctx.language === 'en' ? 'REBUILDING FOCUS FRAMEWORK' : 'RECONSTRUCTION DU CADRE DE CONCENTRATION',
    ],
    procrastination: [
      ctx.language === 'en' ? 'REBUILDING FOCUS STRUCTURE' : 'RECONSTRUCTION DE LA STRUCTURE DE CONCENTRATION',
      ctx.language === 'en' ? 'REDUCING DISTRACTION DEPENDENCY' : 'RÉDUCTION DE LA DÉPENDANCE À LA DISTRACTION',
    ],
    energy: [
      ctx.language === 'en' ? 'OPTIMIZING ENERGY ALLOCATION' : 'OPTIMISATION DE L\'ALLOCATION D\'ÉNERGIE',
      ctx.language === 'en' ? 'REBUILDING RECOVERY CYCLES' : 'RECONSTRUCTION DES CYCLES DE RÉCUPÉRATION',
    ],
    habit: [
      ctx.language === 'en' ? 'STABILIZING BEHAVIORAL CONTROL' : 'STABILISATION DU CONTRÔLE COMPORTEMENTAL',
      ctx.language === 'en' ? 'REDUCING IMPULSE RESPONSE' : 'RÉDUCTION DE LA RÉPONSE D\'IMPULSION',
    ],
    future: [
      ctx.language === 'en' ? 'REBUILDING DIRECTIONAL STABILITY' : 'RECONSTRUCTION DE LA STABILITÉ DIRECTIONNELLE',
      ctx.language === 'en' ? 'OPTIMIZING GOAL ALIGNMENT' : 'OPTIMISATION DE L\'ALIGNEMENT DES OBJECTIFS',
    ],
    general: [
      ctx.language === 'en' ? 'ANALYZING BEHAVIORAL PATTERNS' : 'ANALYSE DES SCHÉMAS COMPORTEMENTAUX',
      ctx.language === 'en' ? 'STABILIZING SYSTEM PARAMETERS' : 'STABILISATION DES PARAMÈTRES SYSTÈME',
    ],
  };

  const keyword = keywords[0] || 'general';
  const statuses = statusTemplates[keyword] || statusTemplates.general;

  return statuses[Math.floor(Math.random() * statuses.length)];
}

export function generateResult(ctx: ExecutionContext): string {
  const tx = t(ctx.language);
  const random = Math.random();

  if (random < 0.75) {
    const successResults = [
      tx('results.complete'),
      tx('results.patch_applied'),
      tx('results.optimization_success'),
      tx('results.stability_restored'),
    ];
    return successResults[Math.floor(Math.random() * successResults.length)];
  } else if (random < 0.9) {
    const partialResults = [
      tx('results.partial'),
      tx('results.additional_recommended'),
    ];
    return partialResults[Math.floor(Math.random() * partialResults.length)];
  } else {
    const failureResults = [
      tx('results.interrupted'),
      tx('results.validation_failed'),
      tx('results.instability_detected'),
    ];
    return failureResults[Math.floor(Math.random() * failureResults.length)];
  }
}
