import { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Settings, X, Brain } from 'lucide-react';
import { t, Language } from './utils/i18n';
import {
  generateExecutionPipeline,
  generateWarning,
  generateStatusText,
  generateResult,
  ExecutionLog,
  ExecutionContext,
  ExecutionPipelineResult,
} from './utils/executionEngine';

type ColorTheme = 'cyan' | 'green' | 'white' | 'purple' | 'red' | 'amber';

const colorThemes: Record<ColorTheme, { primary: string; glow: string; muted: string }> = {
  cyan: { primary: 'text-cyan-400', glow: 'shadow-cyan-500/50', muted: 'text-cyan-600' },
  green: { primary: 'text-green-400', glow: 'shadow-green-500/50', muted: 'text-green-600' },
  white: { primary: 'text-white', glow: 'shadow-white/50', muted: 'text-gray-400' },
  purple: { primary: 'text-purple-400', glow: 'shadow-purple-500/50', muted: 'text-purple-600' },
  red: { primary: 'text-red-400', glow: 'shadow-red-500/50', muted: 'text-red-600' },
  amber: { primary: 'text-amber-400', glow: 'shadow-amber-500/50', muted: 'text-amber-600' },
};

interface HistoryEntry {
  command: string;
  input: string;
  timestamp: Date;
  result: string;
  duration: number;
}

interface TerminalLine {
  id: string;
  text: string;
  type: 'input' | 'output' | 'status' | 'warning' | 'result' | 'progress';
}

interface NeuralProfile {
  firstName: string;
  lastName: string;
  country: string;
}

interface NeuralLog {
  text: string;
  delay: number;
}

export default function App() {
  const [language, setLanguage] = useState<Language>(() => {
    const saved = localStorage.getItem('clife-language');
    return (saved as Language) || 'en';
  });
  const [theme, setTheme] = useState<ColorTheme>(() => {
    const saved = localStorage.getItem('clife-theme');
    return (saved as ColorTheme) || 'cyan';
  });
  const [showSettings, setShowSettings] = useState(false);
  const [showNeuralProfile, setShowNeuralProfile] = useState(false);
  const [neuralProfile, setNeuralProfile] = useState<NeuralProfile>(() => {
    const saved = localStorage.getItem('clife-neural-profile');
    return saved ? JSON.parse(saved) : { firstName: '', lastName: '', country: '' };
  });
  const [isNeuralInjecting, setIsNeuralInjecting] = useState(false);
  const [neuralLogs, setNeuralLogs] = useState<NeuralLog[]>([]);
  const [neuralProgress, setNeuralProgress] = useState(0);
  const [neuralComplete, setNeuralComplete] = useState(false);
  const [lines, setLines] = useState<TerminalLine[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isExecuting, setIsExecuting] = useState(false);
  const [progress, setProgress] = useState(0);
  const [currentStatus, setCurrentStatus] = useState('');
  const [uptime, setUptime] = useState(0);
  const [history, setHistory] = useState<HistoryEntry[]>(() => {
    const saved = localStorage.getItem('clife-history');
    return saved ? JSON.parse(saved) : [];
  });
  const [historyIndex, setHistoryIndex] = useState(-1);
  const [tempInput, setTempInput] = useState('');
  const [awaitingInput, setAwaitingInput] = useState<string | null>(null);
  const [sessionId] = useState(() => `S-${Math.random().toString(36).substring(2, 8).toUpperCase()}`);

  const terminalRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    localStorage.setItem('clife-language', language);
  }, [language]);

  useEffect(() => {
    localStorage.setItem('clife-theme', theme);
  }, [theme]);

  useEffect(() => {
    localStorage.setItem('clife-history', JSON.stringify(history));
  }, [history]);

  useEffect(() => {
    if (neuralProfile.firstName || neuralProfile.lastName || neuralProfile.country) {
      localStorage.setItem('clife-neural-profile', JSON.stringify(neuralProfile));
    }
  }, [neuralProfile]);

  useEffect(() => {
    const interval = setInterval(() => {
      setUptime((prev) => prev + 1);
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (terminalRef.current) {
      terminalRef.current.scrollTop = terminalRef.current.scrollHeight;
    }
  }, [lines]);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const formatUptime = (seconds: number) => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const generateNeuralInjectionLogs = useCallback((profile: NeuralProfile): NeuralLog[] => {
    const logs: NeuralLog[] = [];
    const { firstName, lastName, country } = profile;
    const fullName = `${firstName} ${lastName}`.trim() || 'USER';

    const connectionLogs = [
      { text: `Connecting the C://LIFE terminal to your brain data...`, delay: 2000 },
      { text: `Initializing neural handshake protocol...`, delay: 1800 },
      { text: `Establishing secure identity channel...`, delay: 1500 },
    ];

    const analysisLogs = [
      { text: `Scanning identity matrix for ${fullName}...`, delay: 2200 },
      { text: `Cross-referencing ${country || 'global'} registry databases...`, delay: 2500 },
      { text: `Mapping neural signature patterns...`, delay: 1800 },
      { text: `Analyzing behavioral fingerprint for ${firstName || 'subject'}...`, delay: 2000 },
    ];

    const synchronizationLogs = [
      { text: `Synchronizing profile data with runtime kernel...`, delay: 2200 },
      { text: `Validating ${lastName || 'user'} identity credentials...`, delay: 1900 },
      { text: `Indexing neural pathways for ${fullName}...`, delay: 2100 },
      { text: `Calibrating contextual awareness module...`, delay: 1800 },
      { text: `Linking ${country || 'regional'} behavioral patterns...`, delay: 2000 },
    ];

    const verificationLogs = [
      { text: `Verifying neural profile integrity...`, delay: 1500 },
      { text: `Confirming ${firstName || 'user'} signature authenticity...`, delay: 1700 },
      { text: `Finalizing identity synchronization...`, delay: 1800 },
    ];

    return [...connectionLogs, ...analysisLogs, ...synchronizationLogs, ...verificationLogs];
  }, []);

  const handleNeuralInject = useCallback(async () => {
    if (!neuralProfile.firstName && !neuralProfile.lastName && !neuralProfile.country) {
      return;
    }

    setIsNeuralInjecting(true);
    setNeuralProgress(0);
    setNeuralComplete(false);

    const logs = generateNeuralInjectionLogs(neuralProfile);
    setNeuralLogs(logs);

    for (let i = 0; i < logs.length; i++) {
      await new Promise((r) => setTimeout(r, logs[i].delay));
      setNeuralProgress(Math.round(((i + 1) / logs.length) * 100));
    }

    await new Promise((r) => setTimeout(r, 800));
    setNeuralComplete(true);
    setIsNeuralInjecting(false);
  }, [neuralProfile, generateNeuralInjectionLogs]);

  const closeNeuralProfile = useCallback(() => {
    setShowNeuralProfile(false);
    setNeuralLogs([]);
    setNeuralProgress(0);
    setNeuralComplete(false);
    setIsNeuralInjecting(false);
  }, []);

  const addLine = useCallback((text: string, type: TerminalLine['type']) => {
    setLines((prev) => [...prev, { id: `${Date.now()}-${Math.random()}`, text, type }]);
  }, []);

  const generateProgressBar = (percent: number) => {
    const filled = Math.round(percent / 5);
    const empty = 20 - filled;
    return '█'.repeat(filled) + '░'.repeat(empty);
  };

  const processCommand = useCallback(
    async (cmd: string) => {
      const tx = t(language);
      const cleanCmd = cmd.trim().toLowerCase();

      if (awaitingInput) {
        const startTime = Date.now();
        setIsExecuting(true);
        setProgress(0);

        const ctx: ExecutionContext = {
          command: awaitingInput,
          userInput: cmd,
          language,
        };

        const executionResult: ExecutionPipelineResult = generateExecutionPipeline(ctx);
        const pipeline = executionResult.logs;
        let currentProgress = 0;
        const progressIncrement = 100 / pipeline.length;

        for (let i = 0; i < pipeline.length; i++) {
          const log = pipeline[i];

          if (Math.random() < 0.1) {
            const warning = generateWarning(ctx);
            if (warning) {
              addLine(`${tx('warning')} : ${warning}`, 'warning');
              await new Promise((r) => setTimeout(r, 800 + Math.random() * 600));
            }
          }

          addLine(log.text, 'output');
          currentProgress = Math.min(100, (i + 1) * progressIncrement + Math.random() * 3);
          setProgress(Math.round(currentProgress));
          setCurrentStatus(generateStatusText(ctx, currentProgress));

          await new Promise((r) => setTimeout(r, log.delay));
        }

        setProgress(100);
        const result = generateResult(ctx);
        addLine(`\n[${generateProgressBar(100)}] 100%`, 'progress');
        addLine(`${tx('status')} : ${generateStatusText(ctx, 100).toUpperCase()}`, 'status');
        addLine(`\n${result}`, 'result');

        const duration = Date.now() - startTime;
        setHistory((prev) => [
          ...prev,
          {
            command: awaitingInput,
            input: cmd,
            timestamp: new Date(),
            result,
            duration,
          },
        ]);

        setIsExecuting(false);
        setAwaitingInput(null);
        setCurrentStatus('');
        return;
      }

      if (cleanCmd === tx('commands.help') || cleanCmd === '/help') {
        const commands = [
          tx('commands.materialize_futur'),
          tx('commands.nullify_fear'),
          tx('commands.procrastination_bypass'),
          tx('commands.love_potion'),
          tx('commands.urge_blocker'),
          tx('commands.energy_unlocker'),
          '',
          tx('commands.help'),
          tx('commands.history'),
          tx('commands.clear'),
        ];
        commands.forEach((c) => addLine(c, 'output'));
        return;
      }

      if (cleanCmd === tx('commands.history') || cleanCmd === '/history') {
        if (history.length === 0) {
          addLine(tx('history.noHistory'), 'output');
          return;
        }
        addLine(`\n${tx('history.title')}`, 'status');
        addLine('─'.repeat(40), 'output');
        history.forEach((entry, idx) => {
          addLine(`\n[${idx + 1}] ${entry.command}`, 'output');
          addLine(`    ${entry.input}`, 'output');
          addLine(`    ${tx('history.result')}: ${entry.result}`, 'output');
          addLine(`    ${tx('history.duration')}: ${(entry.duration / 1000).toFixed(1)}s`, 'output');
        });
        return;
      }

      if (cleanCmd === tx('commands.clear') || cleanCmd === '/clear') {
        setLines([]);
        return;
      }

      const validCommands = [
        'materialize_futur',
        'nullify_fear',
        'procrastination_bypass',
        'love_potion',
        'urge_blocker',
        'energy_unlocker',
      ];

      const isFrenchCommand = language === 'fr';
      const commandMap: Record<string, string[]> = {
        materialize_futur: isFrenchCommand ? ['/materialiser_futur'] : ['/materialize_futur'],
        nullify_fear: isFrenchCommand ? ['/annuler_peur'] : ['/nullify_fear'],
        procrastination_bypass: isFrenchCommand
          ? ['/contournement_procrastination']
          : ['/procrastination_bypass'],
        love_potion: isFrenchCommand ? ['/potion_amour'] : ['/love_potion'],
        urge_blocker: isFrenchCommand ? ['/bloqueur_envies'] : ['/urge_blocker'],
        energy_unlocker: isFrenchCommand ? ['/debloqueur_energie'] : ['/energy_unlocker'],
      };

      const matchedCommand = validCommands.find(
        (cmd) => cleanCmd === `/${cmd}` || commandMap[cmd]?.includes(cleanCmd)
      );

      if (matchedCommand) {
        addLine(tx('directiveAcknowledged'), 'output');
        addLine(tx('describeOptimization'), 'output');
        setAwaitingInput(`/${matchedCommand}`);
        return;
      }

      addLine(`unknown directive: ${cmd}`, 'warning');
    },
    [language, addLine, history, awaitingInput]
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim() || isExecuting) return;

    addLine(`> ${inputValue}`, 'input');
    processCommand(inputValue);
    setHistory((prev) => [...prev.slice(-99)]);
    setInputValue('');
    setHistoryIndex(-1);
    setTempInput('');
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    const execCommands = history.map((h) => h.command);

    if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (historyIndex === -1) {
        setTempInput(inputValue);
      }
      if (historyIndex < execCommands.length - 1) {
        const newIndex = historyIndex + 1;
        setHistoryIndex(newIndex);
        setInputValue(execCommands[execCommands.length - 1 - newIndex] || '');
      }
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (historyIndex > 0) {
        const newIndex = historyIndex - 1;
        setHistoryIndex(newIndex);
        setInputValue(execCommands[execCommands.length - 1 - newIndex] || '');
      } else if (historyIndex === 0) {
        setHistoryIndex(-1);
        setInputValue(tempInput);
      }
    }
  };

  const themeColors = colorThemes[theme];

  return (
    <div
      className={`min-h-screen bg-black font-mono text-sm relative overflow-hidden ${themeColors.primary}`}
      onClick={() => inputRef.current?.focus()}
    >
      {/* CRT scanlines effect */}
      <div
        className="pointer-events-none absolute inset-0 z-50 opacity-[0.03]"
        style={{
          background:
            'repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,0,0,0.3) 2px, rgba(0,0,0,0.3) 4px)',
        }}
      />

      {/* Top bar */}
      <div className="fixed top-0 left-0 right-0 z-40 flex items-center justify-between px-6 py-3 border-b border-white/5 bg-black/80 backdrop-blur-sm">
        <div className="flex items-center gap-4">
          <span
            className={`text-lg font-bold tracking-wider ${themeColors.primary} drop-shadow-[0_0_10px_currentColor]`}
          >
            {t(language)('logo')}
          </span>
          <div className="flex items-center gap-4 text-xs text-white/40">
            <span>
              {t(language)('session')}: {sessionId}
            </span>
            <span>
              {t(language)('uptime')}: {formatUptime(uptime)}
            </span>
          </div>
        </div>
        <div className="flex items-center gap-1">
          <button
            onClick={() => setShowNeuralProfile(true)}
            className={`p-2 rounded-lg transition-all duration-300 hover:bg-white/5 ${themeColors.primary} hover:drop-shadow-[0_0_8px_currentColor]`}
          >
            <Brain className="w-4 h-4" />
          </button>
          <button
            onClick={() => setShowSettings(true)}
            className={`p-2 rounded-lg transition-colors hover:bg-white/5 ${themeColors.primary}`}
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Terminal area */}
      <div
        ref={terminalRef}
        className="pt-20 pb-24 px-6 h-screen overflow-y-auto scroll-smooth"
        style={{ scrollbarWidth: 'thin', scrollbarColor: 'rgba(255,255,255,0.1) transparent' }}
      >
        <AnimatePresence mode="popLayout">
          {lines.map((line) => (
            <motion.div
              key={line.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.2 }}
              className={`py-0.5 ${
                line.type === 'input'
                  ? `${themeColors.primary}`
                  : line.type === 'warning'
                    ? 'text-red-400'
                    : line.type === 'result'
                      ? `${themeColors.primary} font-semibold`
                      : line.type === 'status'
                        ? `${themeColors.muted}`
                        : line.type === 'progress'
                          ? `${themeColors.primary}`
                          : 'text-white/60'
              }`}
            >
              {line.text}
            </motion.div>
          ))}
        </AnimatePresence>

        {/* Progress bar during execution */}
        <AnimatePresence>
          {isExecuting && progress > 0 && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="mt-4"
            >
              <div className={`text-xs ${themeColors.muted} mb-2`}>{currentStatus}</div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Command input */}
      <div className="fixed bottom-0 left-0 right-0 z-40 bg-black/90 backdrop-blur-sm border-t border-white/5">
        <form onSubmit={handleSubmit} className="flex items-center gap-3 px-6 py-4">
          <span
            className={`text-base font-bold tracking-wider ${themeColors.primary} drop-shadow-[0_0_12px_currentColor]`}
          >
            {t(language)('logo')}
          </span>
          <span className={`${themeColors.primary} opacity-50`}>{'>'}</span>
          <div className="flex-1 relative">
            <input
              ref={inputRef}
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder={t(language)('placeholder')}
              disabled={isExecuting}
              className={`w-full bg-transparent outline-none ${themeColors.primary} placeholder-white/20 ${isExecuting ? 'opacity-50' : ''}`}
              autoComplete="off"
              spellCheck={false}
            />
            {!isExecuting && !inputValue && (
              <span
                className={`absolute top-0 left-0 w-2 h-5 ${themeColors.primary} animate-pulse`}
                style={{
                  backgroundColor: 'currentColor',
                  boxShadow: '0 0 8px currentColor',
                }}
              />
            )}
          </div>
        </form>
      </div>

      {/* Settings modal */}
      <AnimatePresence>
        {showSettings && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
            onClick={() => setShowSettings(false)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-sm bg-black/90 border border-white/10 rounded-lg shadow-2xl"
            >
              <div className="flex items-center justify-between p-4 border-b border-white/10">
                <h3 className={`text-base font-semibold ${themeColors.primary}`}>
                  {t(language)('settings.title')}
                </h3>
                <button
                  onClick={() => setShowSettings(false)}
                  className="p-1 rounded hover:bg-white/5 text-white/60 hover:text-white transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="p-4 space-y-4">
                {/* Language */}
                <div>
                  <label className="block text-xs text-white/40 mb-2 uppercase tracking-wider">
                    {t(language)('settings.language')}
                  </label>
                  <div className="flex gap-2">
                    <button
                      onClick={() => setLanguage('en')}
                      className={`flex-1 px-4 py-2 rounded text-sm transition-all ${language === 'en' ? `bg-white/10 ${themeColors.primary} border border-current` : 'text-white/40 hover:text-white/70 border border-white/10'}`}
                    >
                      English
                    </button>
                    <button
                      onClick={() => setLanguage('fr')}
                      className={`flex-1 px-4 py-2 rounded text-sm transition-all ${language === 'fr' ? `bg-white/10 ${themeColors.primary} border border-current` : 'text-white/40 hover:text-white/70 border border-white/10'}`}
                    >
                      Francais
                    </button>
                  </div>
                </div>

                {/* Theme */}
                <div>
                  <label className="block text-xs text-white/40 mb-2 uppercase tracking-wider">
                    {t(language)('settings.theme')}
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    {(Object.keys(colorThemes) as ColorTheme[]).map((color) => (
                      <button
                        key={color}
                        onClick={() => setTheme(color)}
                        className={`px-3 py-2 rounded text-xs capitalize transition-all ${theme === color ? `bg-white/10 ${colorThemes[color].primary} border border-current` : 'text-white/40 hover:text-white/70 border border-white/10'}`}
                      >
                        {color}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Neural Profile modal */}
      <AnimatePresence>
        {showNeuralProfile && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
            onClick={closeNeuralProfile}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-sm bg-black/90 border border-white/10 rounded-lg shadow-2xl"
            >
              <div className="flex items-center justify-between p-4 border-b border-white/10">
                <div className="flex items-center gap-2">
                  <Brain className={`w-4 h-4 ${themeColors.primary}`} />
                  <h3 className={`text-base font-semibold ${themeColors.primary}`}>
                    NEURAL PROFILE
                  </h3>
                </div>
                <button
                  onClick={closeNeuralProfile}
                  className="p-1 rounded hover:bg-white/5 text-white/60 hover:text-white transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="p-4 space-y-4">
                {!isNeuralInjecting && !neuralComplete ? (
                  <>
                    {/* First Name */}
                    <div>
                      <label className="block text-xs text-white/40 mb-2 uppercase tracking-wider">
                        First Name
                      </label>
                      <input
                        type="text"
                        value={neuralProfile.firstName}
                        onChange={(e) => setNeuralProfile((prev) => ({ ...prev, firstName: e.target.value }))}
                        placeholder="Enter first name..."
                        className={`w-full px-3 py-2 bg-transparent border border-white/20 rounded text-sm ${themeColors.primary} placeholder-white/20 focus:border-cyan-500/50 focus:bg-white/5 transition-all outline-none`}
                        disabled={isNeuralInjecting}
                      />
                    </div>

                    {/* Last Name */}
                    <div>
                      <label className="block text-xs text-white/40 mb-2 uppercase tracking-wider">
                        Last Name
                      </label>
                      <input
                        type="text"
                        value={neuralProfile.lastName}
                        onChange={(e) => setNeuralProfile((prev) => ({ ...prev, lastName: e.target.value }))}
                        placeholder="Enter last name..."
                        className={`w-full px-3 py-2 bg-transparent border border-white/20 rounded text-sm ${themeColors.primary} placeholder-white/20 focus:border-cyan-500/50 focus:bg-white/5 transition-all outline-none`}
                        disabled={isNeuralInjecting}
                      />
                    </div>

                    {/* Country */}
                    <div>
                      <label className="block text-xs text-white/40 mb-2 uppercase tracking-wider">
                        Country
                      </label>
                      <input
                        type="text"
                        value={neuralProfile.country}
                        onChange={(e) => setNeuralProfile((prev) => ({ ...prev, country: e.target.value }))}
                        placeholder="Enter country..."
                        className={`w-full px-3 py-2 bg-transparent border border-white/20 rounded text-sm ${themeColors.primary} placeholder-white/20 focus:border-cyan-500/50 focus:bg-white/5 transition-all outline-none`}
                        disabled={isNeuralInjecting}
                      />
                    </div>

                    {/* Inject Button */}
                    <button
                      onClick={handleNeuralInject}
                      disabled={!neuralProfile.firstName && !neuralProfile.lastName && !neuralProfile.country}
                      className={`w-full py-2 px-4 rounded text-sm font-semibold transition-all ${
                        neuralProfile.firstName || neuralProfile.lastName || neuralProfile.country
                          ? `bg-white/10 ${themeColors.primary} border border-current hover:bg-white/15 hover:drop-shadow-[0_0_8px_currentColor]`
                          : 'bg-white/5 text-white/30 border border-white/10 cursor-not-allowed'
                      }`}
                    >
                      INJECT
                    </button>
                  </>
                ) : (
                  <>
                    {/* Injection Progress */}
                    <div className="space-y-4">
                      {/* Loading Circle */}
                      {!neuralComplete && (
                        <motion.div
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          className="flex justify-center py-4"
                        >
                          <div className={`relative w-16 h-16 ${themeColors.primary}`}>
                            <svg
                              className={`w-16 h-16 animate-spin`}
                              style={{ animationDuration: '2s' }}
                              viewBox="0 0 50 50"
                            >
                              <circle
                                cx="25"
                                cy="25"
                                r="20"
                                fill="none"
                                stroke="currentColor"
                                strokeWidth="2"
                                strokeOpacity="0.2"
                              />
                              <circle
                                cx="25"
                                cy="25"
                                r="20"
                                fill="none"
                                stroke="currentColor"
                                strokeWidth="2"
                                strokeLinecap="round"
                                strokeDasharray={`${neuralProgress * 1.256}, 125.6`}
                                transform="rotate(-90 25 25)"
                                style={{
                                  filter: 'drop-shadow(0 0 6px currentColor)',
                                }}
                              />
                            </svg>
                            <div className="absolute inset-0 flex items-center justify-center">
                              <span className={`text-xs font-semibold ${themeColors.primary}`}>
                                {neuralProgress}%
                              </span>
                            </div>
                          </div>
                        </motion.div>
                      )}

                      {/* Brain Connection Logs */}
                      <div className="min-h-[200px] overflow-y-auto">
                        <AnimatePresence mode="popLayout">
                          {neuralLogs.map((log, idx) => (
                            <motion.div
                              key={idx}
                              initial={{ opacity: 0, x: -10 }}
                              animate={{ opacity: 1, x: 0 }}
                              transition={{ duration: 0.4, ease: 'easeOut' }}
                              className={`text-xs py-1.5 ${themeColors.primary} opacity-80`}
                            >
                              {`> ${log.text}`}
                            </motion.div>
                          ))}
                        </AnimatePresence>
                      </div>

                      {/* Completion State */}
                      {neuralComplete && (
                        <motion.div
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          className={`mt-4 space-y-1 ${themeColors.primary}`}
                        >
                          <motion.div
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            transition={{ delay: 0.1 }}
                            className="text-xs"
                          >{`> neural profile synchronized.`}</motion.div>
                          <motion.div
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            transition={{ delay: 0.2 }}
                            className="text-xs"
                          >{`> identity verification complete.`}</motion.div>
                          <motion.div
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            transition={{ delay: 0.3 }}
                            className="text-xs"
                          >{`> runtime access granted.`}</motion.div>
                          <motion.div
                            initial={{ opacity: 0, scale: 0.95 }}
                            animate={{ opacity: 1, scale: 1 }}
                            transition={{ delay: 0.5 }}
                            className="text-sm font-semibold mt-4 text-center drop-shadow-[0_0_10px_currentColor]"
                          >
                            NEURAL SIGNATURE VERIFIED
                          </motion.div>
                        </motion.div>
                      )}
                    </div>
                  </>
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
